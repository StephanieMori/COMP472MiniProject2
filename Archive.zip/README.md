# COMP472MiniProject2

Team members :
Stephanie Mori      40046039
Rama Alrifai        40116096

link to github :
https://github.com/StephanieMori/COMP472MiniProject2

To be added:
- clear instructions on how to run the program
- any details count
- maybe some details on how our written code works and why

                             Line'em up!
  
    The purpose of this group project is to recycle a program for the game tic-tac-toe , and develope a program for a new game called Line'em up. The new game is essentially the same as tic-tac-toe, yet it includes more factors and restrictions. The program implements an AI that is taught by us; using adversial search methods heuristic functions and algorithms.

   Initially, the user is prompted to enter the game parameters which are n(range of baord size), b(#of block tiles), s(#of tiles for a winning streak), and t(max. time in seconds for each turn). Following that, the user picks a mode such as AI-Human, then the depths of each player/AI and which heuristic function to implement. After all that input, the game baord is printed on the screen; Since we implemented adersial search methods: minimax() and Alpha-pruning, the game will iterate over every possibilty of every available space, and implement recursion in order to climb up to the root node value. Finally, the program will output the recommended next move and the game continues until we reach a winning streak. 
